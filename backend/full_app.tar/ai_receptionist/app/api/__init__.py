"""API routers package (modular endpoints)."""
