"""Pydantic DTOs for API inputs/outputs."""
