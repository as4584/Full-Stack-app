"""Core package: settings, DI container, cross-cutting concerns."""
