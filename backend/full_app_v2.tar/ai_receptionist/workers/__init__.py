"""Background task workers (async processing, queues, etc.)."""
