"""Telephony services (interfaces and implementations)."""
