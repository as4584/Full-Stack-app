"""Database adapters and repositories."""
