"""
Pytest configuration and fixtures for ai_receptionist tests.
"""

from pathlib import Path

# Get project root for test fixtures
PROJECT_ROOT = Path(__file__).parent.parent.parent
