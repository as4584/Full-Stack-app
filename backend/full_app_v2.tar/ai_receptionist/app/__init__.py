"""API package for FastAPI routers and app setup."""
